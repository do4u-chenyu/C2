#
# The content of this file will be filled in with meaningful data when creating an archive using `git archive` or by
# downloading an archive from github, e.g., from github.com/.../archive/develop.zip
#
rev = "fcff15e6e7"  # abbreviated commit hash
commit = "fcff15e6e7ab6fad135c584c2b6cc5e0f7809319"  # commit hash
date = "2022-01-07 22:29:32 +0000"  # commit date
author = "bwoodsend <bwoodsend@gmail.com>"
ref_names = "tag: v4.8"  # incl. current branch
commit_message = """Release v4.8.
"""
