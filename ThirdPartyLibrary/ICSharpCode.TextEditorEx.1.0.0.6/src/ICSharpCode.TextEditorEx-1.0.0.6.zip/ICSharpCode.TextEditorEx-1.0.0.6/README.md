ICSharpCode.TextEditorEx
========================

Extended version based on ICSharpCode.TextEditor which supports Search/Replace and GotoLineNumber
