﻿using System.Drawing;
using System.Windows.Forms;

namespace WinFormTestXmlEditor
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            textEditorControl1.FoldingStrategy = "XML";
            textEditorControl1.SyntaxHighlighting = "Python";
            
            //textEditorControl1.Font = new Font("Courier New", 8.25f, FontStyle.Regular);

            //UpdateAndCheckFoldings();
        }

        private void textEditorControl1_TextChanged(object sender, System.EventArgs e)
        {
            UpdateAndCheckFoldings();
        }

        private void UpdateAndCheckFoldings()
        {
            textEditorControl1.Document.FoldingManager.UpdateFoldings(null, null);
            textBox1.Text = string.Join("\r\n", textEditorControl1.GetFoldingErrors());
        }
    }
}