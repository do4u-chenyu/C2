using System;

namespace Thrift.Protocol
{
	public enum TMessageType
	{
		Call = 1,
		Reply = 2,
		Exception = 3,
		Oneway = 4
	}
}